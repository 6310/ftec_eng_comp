//programa que le os dados de pessoas e grava em arquivo
//depois le o arquivo e mostra na tela
#include <stdio.h>
#include <stdlib.h>
#define max 5
struct Pessoa {
 int codigo;
 char nome[50];
 int idade;
};
main() {
    FILE *pf;
    Pessoa dados;
    int i;
    
    if((pf = fopen("arquivo.bin", "wb")) == NULL){
     printf("Erro na abertura do arquivo");
    }
    printf("\nLeitura\n");
    for(i=0;i<max;i++){
        printf("Codigo: ");
        scanf("%d",&dados.codigo);
        printf("Nome: ");
        fflush(stdin);
        gets(dados.nome);
        printf("Idade: ");
        scanf("%d",&dados.idade);
        
        if(fwrite(&dados, sizeof(dados), 1,pf) != 1)   /* Escreve 1 registro no arquivo */
            printf("Erro na escrita do arquivo");
    }//fim da grava��o de dados
    fclose(pf);/* Fecha o arquivo */
    if((pf = fopen("arquivo.bin", "rb")) == NULL){ /* Abre o arquivo para nova leitura */
        printf("Erro na abertura do arquivo");
    }
    printf("\nLidos\n");
    while(!feof(pf)){
     if(fread(&dados, sizeof(dados), 1,pf) != 1)  //le um registro do arquivo
        printf("\nFim\n");
     else
        printf("\nPessoa: %d, %s, %d\n", dados.codigo,dados.nome,dados.idade);
    }
    fclose(pf);
    printf("\n");
    system("pause");
}
