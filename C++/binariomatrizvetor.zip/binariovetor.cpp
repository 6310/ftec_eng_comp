#include <stdio.h>
#include <stdlib.h>
main() {
FILE *pf;
float vetor[10];
float vetorlido[10];
int i;
for(i=0;i<10;i++){
  printf("Elemento[%d]:",i+1);
  scanf("%f",&vetor[i]);
}
if((pf = fopen("arquivo.bin", "wb")) == NULL){
 printf("Erro na abertura do arquivo");
}
if(fwrite(vetor, 10*sizeof(float), 1,pf) != 1)   /* Escreve a vari�vel pi */
    printf("Erro na escrita do arquivo");
fclose(pf);                                    /* Fecha o arquivo */
if((pf = fopen("arquivo.bin", "rb")) == NULL){ /* Abre o arquivo para nova leitura */
    printf("Erro na abertura do arquivo");
}
if(fread(vetorlido,10*sizeof(float), 1,pf) != 1)  /* Le em pilido o valor da vari�vel armazenada anteriormente */
    printf("Erro na leitura do arquivo");
for(i=0;i<10;i++)
 printf("Vetor[%d]: %f\n",i+1,vetorlido[i]);
fclose(pf);
system("pause");
}
