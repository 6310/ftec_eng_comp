#include <stdio.h>
#include <stdlib.h>
#define max 5
main() {
FILE *pf;
float matriz[max][max];
float matrizlido[max][max];
int i,j;
for(i=0;i<max;i++)
 for(j=0;j<max;j++){
   printf("Elemento[%d,%d]:",i+1,j+1);
   scanf("%f",&matriz[i][j]);
}
if((pf = fopen("arquivo.bin", "wb")) == NULL){
 printf("Erro na abertura do arquivo");
}
if(fwrite(matriz,sizeof(matriz),1,pf) != 1)   /* Escreve a vari�vel pi */
    printf("Erro na escrita do arquivo");
fclose(pf);                                    /* Fecha o arquivo */
if((pf = fopen("arquivo.bin", "rb")) == NULL){ /* Abre o arquivo para nova leitura */
    printf("Erro na abertura do arquivo");
}
if(fread(matrizlido,sizeof(matrizlido), 1,pf)!=1)  /* Le em pilido o valor da vari�vel armazenada anteriormente */
    printf("Erro na leitura do arquivo");
for(i=0;i<max;i++){
 printf("\n");
 for(j=0;j<max;j++)
   printf("%5.2f  ",matrizlido[i][j]);
 }
fclose(pf);
printf("\n\n");
system("pause");
}
